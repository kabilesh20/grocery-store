import React from 'react'

const Terms = () => {
  return (
    <div>Wishlist</div>
  )
}

export default Terms