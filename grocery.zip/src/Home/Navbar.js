import React from 'react';
import './Navbar.css';
import {  Link } from "react-router-dom";
import Searchbar from './Searchbar';
import store from '..//images/gs.jpeg';
import footer from'..//images/gs.jpeg';
const Navbar= () =>{
  return (
  <div className='nav'>
    <div className='nav1'>
        
        
        <li>
        <Link to="/brand">Brand</Link>
        </li>
        <li>
        <Link to="/price">Price</Link>
        </li>
        <li>
        <Link to="/popularity">Popularity</Link>
        </li>
        <img src={store}></img>
        
        <li>
        <Link to="/home">Home</Link>
        </li>
        <li>
        <Link to="/mybag">MyBag</Link>
        </li>
        <li>
        <Link to="/wishlist">Wishlist</Link>
        </li>
        <li>
        <Link to="/Login">Login/Register</Link>
        </li>
    </div>
    <div className='nav2'>
      <p></p>
      <li id='search'><Searchbar/></li>
      <div className="button-container">
        <Link to='/All'>
          <button type="button" class="shop-button btn btn-danger">
            Shop Now
          </button>
          </Link>
      </div>
    </div>
    <div className='footer'>
      <img src={footer}></img>
      <div className='links'>
          <li id='term'>
          <Link to="/term">Terms and Conditions</Link>
          </li>
          <li id='pay'>
          <Link to="/payment">Payment and Return Policy</Link>
          </li>
          <li id='contact'>
          <Link to="/contact">Contact</Link>
          </li>
          <p> All rights reserved. All audio, visual and textual content on this site (including all names, characters, images, trademarks and logos) are</p>
          <p id='inline'>protected by trademarks, copyrights and other Intellectual Property rights owned by ToyVerse or its subsidiaries, licensors, licensees, suppliers and accounts.</p>
      </div>
     
    </div>
  </div>
  );
}
export default Navbar;