import React from 'react'

const Track = () => {
  return (
    <div>Track</div>
  )
}

export default Track