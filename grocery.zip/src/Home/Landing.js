import React from 'react'

const Landing = () => {
  return (
    <div>Home</div>
  )
}

export default Landing