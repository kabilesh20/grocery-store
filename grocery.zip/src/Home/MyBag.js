import React from 'react'

const MyBag = () => {
  return (
    <div>MyBag</div>
  )
}

export default MyBag