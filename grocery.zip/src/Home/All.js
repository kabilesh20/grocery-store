import React from 'react'
import pro1 from './oreo.jpeg'
import pro2 from './jj.jpeg'
import {  Link } from "react-router-dom";
import './All.css'
const All = () => {
  return (
    <>
    <div className='nav1'>  
        <li>
        <Link to="/age">Age</Link>
        </li>
        <li>
        <Link to="/brand">Brand</Link>
        </li>
        <li>
        <Link to="/price">Price</Link>
        </li>
        <li>
        <Link to="/popularity">Popularity</Link>
        </li>
        <img src=''></img>
        
        <li>
        <Link to="/home">Home</Link>
        </li>
        <li>
        <Link to="/mybag">MyBag</Link>
        </li>
        <li>
        <Link to="/wishlist">Wishlist</Link>
        </li>
        <li>
        <Link to="/Login">Login/Register</Link>
        </li>
    </div>
    <div className='pic1'>
        <img src={pro1}></img>
        <img src={pro2}></img>
    </div>
    </>
  )
}

export default All