import React from 'react';
import { BrowserRouter , Routes, Route } from 'react-router-dom';
import LoginPage from './Home/Login'
import SignupPage from './Home/Signup';
import ResetPasswordPage from './Home/Resetpwd';
import Landing from './Home/Landing';
import Wishlist from './Home/Wishlist';
import Track from './Home/Track';
import MyBag from './Home/MyBag';
import Navbar from './Home/Navbar';
import All from './Home/All';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navbar />} />
        <Route path="/Login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="/landing" element={<Landing />} />
        <Route path="/wishlist" element={<Wishlist />} />
        <Route path="/track" element={<Track />} />
        <Route path="/mybag" element={<MyBag />} />
        <Route path="/all" element={<All />} />
        <Route path="/terms" element={<All />} />

        
      </Routes>
    </BrowserRouter>
  );
};

export default App;
